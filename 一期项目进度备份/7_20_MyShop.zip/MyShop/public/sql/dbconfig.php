<?php
	//数据库配置文件 
	define("HOST","localhost");//主机名
	define("USER","root");//用户名
	define("PASS","zwt12345");//密码
	define("DBNAME","myshop");//数据库 