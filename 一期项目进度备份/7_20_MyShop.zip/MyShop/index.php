<center>
	<style type="text/css">
		a {
			text-decoration: none;
			color: yellowgreen;
		}
	</style>
	
<h2><a href="./home/index.php">商城前台</a></h2>
<h2><a href="./admin/index.php">商城后台</a></h2>
</center>
