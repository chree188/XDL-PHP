					MyShop目录结构
============================================================================
==========MyShop===========
admin 后台资源文件夹

home 前台资源文件夹

public 公共资源文件夹

index.php MyShop主页


==========home 前台=============
shopCarTJ.php  订单页/订单提交页

shopCarCG.php  订单页/订单提交成功页

lists.php  品牌页/商品列表页

header.php  导航栏头部

iUserCenter.php  个人中心

shopCar.php  购物车页

login.php  前台登录页

register.php  注册页

index.php  前台主页/首页

footer.php  页脚

details.php 商品详情


============admin 后台==============
goods	商品模块资源文件夹

include	后台资源工具包文件夹

orders	订单模块资源文件夹

type	类别模块资源文件夹

users	用户模块资源文件夹

dologin.php	登录处理页

index.php	网站后台主页/首页

login.php	后台管理员登录

logout.php	注销


============public 公共资源===============
css css样式资源文件夹

fonts  字体资源文件夹

img	  图片资源文件夹

js	js资源文件夹

sql 数据库资源文件夹