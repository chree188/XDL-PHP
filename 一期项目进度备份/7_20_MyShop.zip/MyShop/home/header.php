<!--网站头部和导航栏-->
<link href="../public/css/common.css" rel="stylesheet" />
<link href="../public/css/style.css" rel="stylesheet" />

<!--头部-->
<div class="top">
	<div class="link">
		<a class="i" href="login.php">
			登录
		</a>
		&nbsp;&nbsp;
		<a class="a" href="register.php">
			注册
		</a>
		<br />
		<input type="text" class="text08" />
		<input type="button" class="button04" />
		&nbsp;&nbsp;
		<a href="#_" class="sbutton">
			余额查询
		</a>
	</div>
	<div class="logo">
		<a href="#_"></a>
	</div>
</div>
<div class="nav">
	<div class="search">
		<a href="shopCar.php">
			<img src="../public/img/buycar.gif" width="182" height="41" />
		</a>
	</div>
	<ul class="list">
		<li>
			<a class="n01" href="#_"></a>
		</li>
		<li>
			<a class="n02" href="#_"></a>
		</li>
		<li>
			<a class="n03" href="#_"></a>
		</li>
		<li>
			<a class="n04" href="#_"></a>
		</li>
		<li>
			<a class="n05" href="#_"></a>
		</li>
		<li>
			<a class="n06" href="#_"></a>
		</li>
		<li>
			<a class="n07" href="#_"></a>
		</li>
	</ul>
</div>
