<!--网站页脚-->
<link href="../public/css/style.css" rel="stylesheet" />
<!--养生热线-->
<div class="ctel">
	<img src="../public/img/mark.jpg" width="22" height="21" />
	&nbsp;<span class="tt">养生热线：</span>0570-6216550 13777399387
</div>
<div class="footer">
	浙ICP备案12345678  版权所有 天慈天养土特产  技术支持：
	<a href="#_">
		逗你玩科技
	</a>
</div>