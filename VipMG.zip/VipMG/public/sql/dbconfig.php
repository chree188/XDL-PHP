<?php
	//数据库配置文件 
	define("HOST","localhost");	//主机名,数据库地址;可以是数据库服务器ip地址
	define("USER","root");	//数据库登录用户名
	define("PASS","zwt12345");	//登录用户密码
	define("DBNAME","vipmg");	//使用的数据库名 